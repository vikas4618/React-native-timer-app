import React, { createContext, useState, useContext } from 'react';

const TimerContext = createContext();

export const TimerProvider = ({ children }) => {
  const [history, setHistory] = useState([]);

  const addSession = (durationInSeconds) => {
    const session = {
      id: Date.now(),
      duration: durationInSeconds,
      timestamp: new Date().toLocaleString(),
    };
    setHistory(prev => [session, ...prev]);
  };

  return (
    <TimerContext.Provider value={{ history, addSession }}>
      {children}
    </TimerContext.Provider>
  );
};

export const useTimer = () => useContext(TimerContext);
