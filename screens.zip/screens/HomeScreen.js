import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen({ navigation }) {
  const [seconds, setSeconds] = useState(0);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    let interval = null;
    if (running) {
      interval = setInterval(() => {
        setSeconds(prev => prev + 1);
      }, 1000);
    } else if (!running && interval !== null) {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [running]);

  const saveSession = async (duration) => {
    if (duration === 0) return;
    const newEntry = {
      duration,
      time: new Date().toLocaleString(),
    };
    try {
      const existing = await AsyncStorage.getItem('timerHistory');
      const parsed = existing ? JSON.parse(existing) : [];
      parsed.push(newEntry);
      await AsyncStorage.setItem('timerHistory', JSON.stringify(parsed));
    } catch (err) {
      console.error('Failed to save session:', err);
    }
  };

  const handleStartPause = () => {
    if (running) {
      // stopping
      saveSession(seconds);
    }
    setRunning(!running);
  };

  const resetTimer = () => {
    setRunning(false);
    setSeconds(0);
  };

  const goToHistory = () => {
    navigation.navigate('History');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.timerText}>{seconds}s</Text>

      <View style={styles.buttonGroup}>
        <Button title={running ? 'Pause & Save' : 'Start'} onPress={handleStartPause} />
        <Button title="Reset" onPress={resetTimer} />
      </View>

      <Button title="Go to History" onPress={goToHistory} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20,
  },
  timerText: {
    fontSize: 48, fontWeight: 'bold', marginBottom: 20,
  },
  buttonGroup: {
    flexDirection: 'row', gap: 10, marginBottom: 20,
  },
});
